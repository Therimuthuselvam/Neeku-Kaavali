
package Automobile;

abstract class Vehicle
{
	public String modelName();
	public String registrationNumber();
	public String ownerName();
}
